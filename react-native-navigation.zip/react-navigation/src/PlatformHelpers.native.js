/* @flow */

import {
  BackAndroid,
  Linking,
} from 'react-native';

export {
  BackAndroid,
  Linking,
};

