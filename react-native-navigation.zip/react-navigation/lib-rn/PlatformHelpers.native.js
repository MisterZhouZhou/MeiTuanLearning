Object.defineProperty(exports,"__esModule",{value:true});exports.Linking=exports.BackAndroid=undefined;

var _reactNative=require('react-native');exports.





BackAndroid=_reactNative.BackAndroid;exports.
Linking=_reactNative.Linking;